export interface Profile {
  id: string;
  name: string;
  photos: string[];
  vehicle: string;
  modifications: string[];
  description: string;
  raceTypes: string[];
  latitude: number;
  longitude: number;
  created_at: string;
}

export interface Track {
  id: string;
  name: string;
  description: string;
  latitude: number;
  longitude: number;
  type: string;
  length: number;
  created_at: string;
}

export interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  created_at: string;
}

export interface Wager {
  id: string;
  challenger_id: string;
  opponent_id: string;
  amount: string;
  token_address: string;
  status: 'pending' | 'accepted' | 'rejected' | 'completed';
  winner_id?: string;
  created_at: string;
}