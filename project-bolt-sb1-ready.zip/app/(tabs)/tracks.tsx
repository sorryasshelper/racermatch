import { useEffect, useState } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { useSupabaseClient } from '@/lib/supabase';
import { Track } from '@/types';

export default function TracksScreen() {
  const [location, setLocation] = useState<Location.LocationObject | null>(null);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const supabase = useSupabaseClient();

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('Permission to access location was denied');
        return;
      }

      let location = await Location.getCurrentPositionAsync({});
      setLocation(location);
      fetchNearbyTracks(location.coords.latitude, location.coords.longitude);
    })();
  }, []);

  const fetchNearbyTracks = async (latitude: number, longitude: number) => {
    try {
      const { data, error } = await supabase
        .from('tracks')
        .select('*')
        .limit(20);
      
      if (error) throw error;
      setTracks(data || []);
    } catch (error) {
      console.error('Error fetching tracks:', error);
    }
  };

  if (errorMsg) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>{errorMsg}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {location && (
        <MapView
          style={styles.map}
          initialRegion={{
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
          }}>
          {tracks.map((track) => (
            <Marker
              key={track.id}
              coordinate={{
                latitude: track.latitude,
                longitude: track.longitude,
              }}
              title={track.name}
              description={track.description}
            />
          ))}
        </MapView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  map: {
    width: '100%',
    height: '100%',
  },
  errorText: {
    color: '#ff3b30',
    fontSize: 16,
    textAlign: 'center',
    margin: 20,
  },
});