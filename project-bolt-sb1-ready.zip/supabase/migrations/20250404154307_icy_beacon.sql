/*
  # Initial Schema Setup for Racing Social App

  1. Tables
    - profiles: User profiles with racing preferences
    - tracks: Racing track locations and details
    - messages: User-to-user messaging
    - wagers: Crypto wagers between users
    
  2. Security
    - RLS enabled on all tables
    - Policies for authenticated access
*/

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  name text NOT NULL,
  photos text[] NOT NULL DEFAULT '{}',
  vehicle text,
  modifications text[] DEFAULT '{}',
  description text,
  race_types text[] DEFAULT '{}',
  latitude double precision,
  longitude double precision,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read all profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Tracks table
CREATE TABLE IF NOT EXISTS tracks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  type text NOT NULL,
  length numeric,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE tracks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read tracks"
  ON tracks
  FOR SELECT
  TO authenticated
  USING (true);

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid REFERENCES auth.users(id),
  receiver_id uuid REFERENCES auth.users(id),
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read their messages"
  ON messages
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = sender_id OR
    auth.uid() = receiver_id
  );

CREATE POLICY "Users can send messages"
  ON messages
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = sender_id);

-- Wagers table
CREATE TABLE IF NOT EXISTS wagers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  challenger_id uuid REFERENCES auth.users(id),
  opponent_id uuid REFERENCES auth.users(id),
  amount text NOT NULL,
  token_address text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  winner_id uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE wagers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read their wagers"
  ON wagers
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = challenger_id OR
    auth.uid() = opponent_id
  );

CREATE POLICY "Users can create wagers"
  ON wagers
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = challenger_id);