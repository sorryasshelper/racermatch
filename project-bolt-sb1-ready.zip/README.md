
# Project Bolt SB1

🚀 React Native + Expo + Supabase Project  
Includes minimal CI/CD with GitHub Actions + `.env` for local dev secrets

---

## 📦 Getting Started

```bash
npm install
cp .env.example .env
npm start
```

Update your `.env` with Supabase keys and Expo/EAS tokens.

---

## 🧪 Scripts

- `npm run lint` – Lint check
- `npm run tsc` – TypeScript check
- `npm test` – Run unit tests

---

## ⚙️ CI/CD (Lite)

CI/CD auto-runs on push to `main` branch via GitHub Actions:

- ✅ Linting
- ✅ Type checking
- ✅ Unit tests

File: `.github/workflows/expo-ci-lite.yml`

---

## 🔒 Local Secrets

Your `.env` file is ignored by Git and stores:
- `EXPO_PUBLIC_SUPABASE_URL`
- `EXPO_PUBLIC_SUPABASE_ANON_KEY`
- `EXPO_TOKEN`
- `EAS_ACCESS_TOKEN`

DO NOT commit real secrets to GitHub.

---

## 🛠️ To Do

- [ ] Add full Expo publish + EAS build
- [ ] Add Supabase health ping
- [ ] Deploy to Expo.dev via CI
